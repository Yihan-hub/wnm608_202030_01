<?php

session_start();


function print_p($v) {
    echo "<pre>",print_r($v),"</pre>";
}



include_once "auth.php";
function makeConn() {

    @$conn = new mysqli(...makeAuth());

    if($conn->connect_errno) die($conn->connect_error);

    $conn->set_charset('utf8');

    return $conn;
}

function makePDOConn(){
    if(!function_exists('makePDOAuth')) die("No makePDOAuth, check in auth.php");

    try {
        $conn = new PDO(...makePDOAuth());
    } catch(PDOException $e) {
        die($e->getMessage());
    }

    return $conn;
}



function getFileData($url) {
    $file = file_get_contents($url);
    $data = json_decode($file);
    return $data;

}

function getData($sql) { // had wrong value in the parentheses
    $conn = makeConn();

    $result = $conn->query($sql);

    if($conn->errno) die($conn->error);

    $arr = [];
    while($row = $result->fetch_object()) $arr[] = $row;

    $conn->close();

    return $arr;
}



function getRows($conn,$sql) {
    $a = [];

    $result = $conn->query($sql);

    if($conn->errno) die($conn->error);

    while($row = $result->fetch_object()) {
        $a[] = $row;
    }

    return $a;
}






// CART FUNCTIONS

// Array find loops an array looking for the first object that matches a boolean function
function array_find($array,$fn) {
    foreach($array as $o) if($fn($o)) return $o;
    return false;
}


function getCart() {
    return isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
}

function addToCart($id,$amount,$price) {
    $cart = getCart();
    
    $p = array_find(
        $cart,
        function($o) use ($id) { return $o->id==$id; }
    );

    if($p) {
        $p->amount += $amount;
    } else {
        $_SESSION['cart'][] = (object)[
            "id"=>$id,
            "amount"=>$amount,
            "price"=>$price
        ];
    }
}

function getCartItems() {
    $cart = getCart();

    if(empty($cart)) return [];

    $ids = implode(",",array_map(function($o){return $o->id;},$cart));
    $data = getRows(makeConn(),
        "SELECT * FROM `products` WHERE `id` in ($ids)"
    );

    return array_map(function($o) use ($cart) {
        $p = array_find($cart,function($co) use ($o){ return $co->id==$o->id; });
        $o->amount = $p->amount;
        $o->total = $p->amount * $o->price;
        return $o;
    },$data);
}

function getCartTotal($fn) {
    $cart = isset($_SESSION['cart'])?$_SESSION['cart']:[];
    return array_reduce($cart,function($r,$o) use ($fn) {return $fn($r,$o);},0);
}
function getCartTotalItems() {
    return getCartTotal(function($r,$o){return $r+$o->amount;});
}
function  getCartTotalPrice() {
    $cart = isset($_SESSION['cart'])?$_SESSION['cart']:[];
    return array_reduce($cart,function($r,$o){return $r+($o->amount*$o->price);});
}
 
?>