
<div class="footer"> 
	<div id="footer" class="container pad">
		<div class="grid gap display-flex">

			<div class="col-xs-12 col-md-4 ">
				<div >
					<p>Shipping & Returns / Payment Method</p>
					<p>Tel: +1 415 666 0088 / Email: yis@gmail.com</p>
				</div>
			</div>

			<div class="col-xs-12 col-md-4" >
				<div>
					<a href="#" class="fa fa-facebook"></a>
					<a href="#" class="fa fa-twitter"></a>
					<a href="#" class="fa fa-instagram"></a>
					<a href="#" class="fa fa-pinterest"></a>
				</div>
			</div>

			<div class="col-xs-12 col-md-4 " >
			<a href="index.php" >
                <img id=logo src="img/logo-xs-2.png" style="padding-top: 15px;" >
            </a>			
			</div>

		</div>	
	</div>
</div>


<div >
<P id="footer" style="color: #38383c; font-size: 0.7em;">&#169; 2020 Copyright: Yi Han Su, WNM 608</P>
</div>

