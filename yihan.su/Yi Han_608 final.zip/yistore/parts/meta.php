<base href="http://yihan.biz/aau/wnm608/yistore/">  
<!-- not yihanstore/ -->

<meta name="viewport" content="width=device-width">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100;0,500;1,100&display=swap" rel="stylesheet">

<link rel="stylesheet" href="lib/css/styleguide.css">
<link rel="stylesheet" href="lib/css/gridsystem.css">
<link rel="stylesheet" href="css/storetheme.css">
<!-- 5/17/2020 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="lib/js/functions.js"></script>
<script src="js/templates.js"></script>