

<header class="navbar">
	<div class="container display-flex">
		<div class="flex-stretch pad">
			<!-- <h1>Fruit Store</h1> -->
			<a href="index.php" style="display:flex; align-items:center">
                <img id=logo src="img/logo-xs-2.png" >
            </a>
		</div>
		<nav class="nav">
			<ul class="display-flex" style="color: black;">
				<li><a href="index.php">Home</a></li>
				<li><a href="product_list.php">Store</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="product_cart.php">Cart</a></li>
			</ul>
		</nav>
	</div>
</header>